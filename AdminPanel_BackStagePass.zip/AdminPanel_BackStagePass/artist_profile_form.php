<?php
include("./config/db.php");
session_start();

// Messages
$success_message = '';
$error_message = '';

// ---------- HANDLE FORM SUBMISSION ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $artist_name = $conn->real_escape_string($_POST['artist_name']);
        $endorsement = $conn->real_escape_string($_POST['endorsement']);
        $bio = $conn->real_escape_string($_POST['bio']);
        $genre = $conn->real_escape_string($_POST['genre']);
        $booking_fee = floatval($_POST['booking_fee']);

        $social_media = json_encode([
            'tiktok' => $_POST['tiktok'] ?? '',
            'twitter' => $_POST['twitter'] ?? '',
            'instagram' => $_POST['instagram'] ?? '',
            'youtube' => $_POST['youtube'] ?? '',
            'applemusic' => $_POST['applemusic'] ?? '',
            'spotify' => $_POST['spotify'] ?? ''
        ]);

        // Handle file upload
        $profile_image = "";
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
            $upload_dir = "./assets/BACKSTAGE_PICTURES/";
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $filename = "artist_" . time() . "_" . uniqid() . "." . $ext;
            $target_file = $upload_dir . $filename;

            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array(strtolower($ext), $allowed)) {
                if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
                    throw new Exception("Failed to upload profile image.");
                }
                $profile_image = $filename;
            }
        }

        // Check if editing
        if (!empty($_POST['edit_id'])) {
            $edit_id = intval($_POST['edit_id']);

            // If no new image uploaded, keep old one
            if (empty($profile_image)) {
                $result = $conn->query("SELECT profile_image FROM artist_profiles WHERE id=$edit_id");
                $row = $result->fetch_assoc();
                $profile_image = $row['profile_image'];
            }

            $sql = "UPDATE artist_profiles SET 
                        artist_name=?, social_media=?, endorsement=?, booking_fee=?, bio=?, genre=?, profile_image=? 
                    WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssi", $artist_name, $social_media, $endorsement, $booking_fee, $bio, $genre, $profile_image, $edit_id);

            if ($stmt->execute()) {
                $success_message = "Artist profile updated successfully!";
                $_POST = [];
            } else {
                throw new Exception("Failed to update profile: " . $stmt->error);
            }
        } else {
            // INSERT NEW
            $sql = "INSERT INTO artist_profiles (artist_name, social_media, endorsement, booking_fee, bio, genre, profile_image)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssss", $artist_name, $social_media, $endorsement, $booking_fee, $bio, $genre, $profile_image);

            if ($stmt->execute()) {
                $success_message = "Artist profile created successfully!";
                $_POST = [];
            } else {
                throw new Exception("Failed to create artist profile: " . $stmt->error);
            }
        }

    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

// ---------- HANDLE DELETE ----------
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $result = $conn->query("SELECT profile_image FROM artist_profiles WHERE id=$delete_id");
    if ($row = $result->fetch_assoc()) {
        if (!empty($row['profile_image']) && file_exists("./assets/BACKSTAGE_PICTURES/".$row['profile_image'])) {
            unlink("./assets/BACKSTAGE_PICTURES/".$row['profile_image']);
        }
    }
    $conn->query("DELETE FROM artist_profiles WHERE id=$delete_id");
    $success_message = "Artist profile deleted successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Artist Profiles</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="./assets/css/style.css">
<style>
body { font-family: Arial; padding: 20px; background: #f4f4f4; }
.container { max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 12px; }
.form-group { margin-bottom: 15px; }
label { display: block; margin-bottom: 5px; font-weight: bold; }
input[type="text"], input[type="url"], input[type="number"], select, textarea { width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #ccc; }
textarea { resize: vertical; min-height: 80px; }
.submit-btn { background: #e0123f; color: white; padding: 12px 30px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; }
.submit-btn:hover { background: #c81038; }
.alert { padding: 12px; margin-bottom: 15px; border-radius: 6px; }
.alert-success { background: #d4edda; color: #155724; }
.alert-error { background: #f8d7da; color: #721c24; }

.artist-list { display: flex; flex-wrap: wrap; gap: 20px; margin-top: 30px; }
.artist-card { background: #fafafa; padding: 15px; border: 1px solid #ddd; border-radius: 10px; width: 220px; text-align: center; position: relative; }
.artist-card img { width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 10px; }
.artist-card h4 { margin: 5px 0; }
.artist-card p { font-size: 14px; margin: 2px 0; }
.artist-card .actions { margin-top: 10px; }
.artist-card .actions a { margin: 0 5px; color: #e0123f; text-decoration: none; }
.artist-social a { margin-right:5px; font-size:18px; color:#000; }
</style>
</head>
<body>
<?php include("./includes/topbar.php"); ?> 
<div class="admin-container"> 
    <?php include("./includes/sidebar.php"); ?>
    <div class="container">
        <h2>Manage Artist Profiles</h2>

        <?php if($success_message): ?><div class="alert alert-success"><?= $success_message ?></div><?php endif; ?>
        <?php if($error_message): ?><div class="alert alert-error"><?= $error_message ?></div><?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="edit_id" value="<?= $_GET['edit_id'] ?? '' ?>">
            <div class="form-group">
                <label>Artist Name *</label>
                <input type="text" name="artist_name" value="<?= $_POST['artist_name'] ?? '' ?>" required>
            </div>

            <div class="form-group">
                <label>Genre</label>
                <select name="genre">
                    <option value="">Select Genre</option>
                    <?php 
                    $genres = ["Hip Hop","Amapiano","R&B","Pop","Maskandi","Rock","Jazz","Electronic","Classical","Other"];
                    foreach($genres as $g){
                        $selected = (($_POST['genre'] ?? '') == $g) ? 'selected' : '';
                        echo "<option value='$g' $selected>$g</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label>Profile Image</label>
                <input type="file" name="profile_image" accept="image/*">
            </div>

            <div class="form-group">
                <label>Biography</label>
                <textarea name="bio"><?= $_POST['bio'] ?? '' ?></textarea>
            </div>

            <h3>Social Media Links</h3>
            <?php $socials = ['tiktok','twitter','instagram','youtube','applemusic','spotify']; 
            foreach($socials as $s){ ?>
                <div class="form-group">
                    <label><?= ucfirst($s) ?></label>
                    <input type="url" name="<?= $s ?>" value="<?= $_POST[$s] ?? '' ?>">
                </div>
            <?php } ?>

            <div class="form-group">
                <label>Endorsement</label>
                <input type="text" name="endorsement" value="<?= $_POST['endorsement'] ?? '' ?>">
            </div>
            <div class="form-group">
                <label>Booking Fee (R)</label>
                <input type="number" name="booking_fee" value="<?= $_POST['booking_fee'] ?? '0.00' ?>" step="0.01" min="0">
            </div>

            <button type="submit" class="submit-btn"><?= isset($_GET['edit_id']) ? 'Update' : 'Create' ?> Artist Profile</button>
        </form>

        <!-- Artist List -->
        <h2>Existing Artists</h2>
        <div class="artist-list">
        <?php
        $result = $conn->query("SELECT * FROM artist_profiles ORDER BY id DESC");
        while ($artist = $result->fetch_assoc()):
            $sm = json_decode($artist['social_media'], true);
            $img_path = !empty($artist['profile_image']) ? "./assets/BACKSTAGE_PICTURES/" . $artist['profile_image'] : "./assets/BACKSTAGE_PICTURES/default_artist.png";
        ?>
            <div class="artist-card">
                <img src="<?= $img_path ?>" alt="<?= htmlspecialchars($artist['artist_name']) ?>">
                <h4><?= htmlspecialchars($artist['artist_name']) ?></h4>
                <p><strong>Genre:</strong> <?= htmlspecialchars($artist['genre']) ?></p>
                <p><strong>Fee:</strong> R<?= number_format($artist['booking_fee'],2) ?></p>
                <p><strong>Endorsements:</strong> <?= htmlspecialchars($artist['endorsement']) ?></p>
                <p><strong>Bio:</strong> <?= nl2br(htmlspecialchars($artist['bio'])) ?></p>

                <div class="artist-social">
                    <?php if($sm) foreach($sm as $key => $link):
                        if(!empty($link)):
                            $icon = match(strtolower($key)){
                                'tiktok' => "fa-brands fa-tiktok",
                                'twitter' => "fa-brands fa-twitter",
                                'instagram' => "fa-brands fa-instagram",
                                'youtube' => "fa-brands fa-youtube",
                                'applemusic' => "fa-brands fa-apple",
                                'spotify' => "fa-brands fa-spotify",
                                default => ""
                            };
                            if($icon): ?>
                                <a href="<?= htmlspecialchars($link) ?>" target="_blank"><i class="<?= $icon ?>"></i></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>

                <div class="actions">
                    <a href="?edit_id=<?= $artist['id'] ?>"><i class="fa fa-edit"></i></a>
                    <a href="?delete_id=<?= $artist['id'] ?>" onclick="return confirm('Delete this artist?');"><i class="fa fa-trash"></i></a>
                </div>
            </div>
        <?php endwhile; ?>
        </div>

    </div>
</div>
</body>
</html>
