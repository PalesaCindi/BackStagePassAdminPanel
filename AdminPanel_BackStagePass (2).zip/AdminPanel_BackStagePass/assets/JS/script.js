//user page 
function confirmAction(action, id) {
    if (confirm("Are you sure you want to " + action + " this user?")) {
        window.location.href = "users.php?action=" + action + "&id=" + id;
    }
}


//social media & music links 
function addSocialLink() {
    const container = document.getElementById('social-links-container');
    const input = document.createElement('input');
    input.type = 'url';
    input.name = 'social_links[]';
    input.placeholder = 'https://...';
    container.appendChild(input);
}

function confirmDelete(id) {
    if(confirm("Are you sure you want to delete this event?")) {
        window.location.href = "even_info.php?delete_id=" + id;
    }
}