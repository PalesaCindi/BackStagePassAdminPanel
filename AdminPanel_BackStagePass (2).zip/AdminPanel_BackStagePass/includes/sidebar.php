<!----------sidebar.php-------------->
<aside class ="sidebar">
   


    <!-----------SideBar Menu------------>
    <ul>
 <li>
                    <a href="">
                        <span class="icon">
                            <ion-icon name="musical-notes-outline"></ion-icon>  
                        </span>
                        <span class="company-title"> BACKSTAGE PASS</span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        <span class="icon">
                            <ion-icon name="grid-outline"></ion-icon>
                        </span>
                        <span class="title"> Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="team_info.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title"> Team Info</span>
                    </a>
                </li>

                <li>
                    <a href="user.php">
                        <span class="icon">
                            <ion-icon name="person-outline"></ion-icon>
                        </span>
                        <span class="title"> User</span>
                    </a>
                </li>

                <li>
                    <a href="event_info.php">
                        <span class="icon">
                            <ion-icon name="list-outline"></ion-icon>
                        </span>
                        <span class="title"> Event Info</span>
                    </a>
                </li>
                <li>
                    <li>
                    <a href="Profile.php">
                        <span class="icon">
                            <ion-icon name="desktop-outline"></ion-icon> 
                        </span>
                        <span class="title"> Artist Profile </span>
                    </a>
                </li>

                <li>
                    <a href="artist_profile_form.php">
                        <span class="icon">
                            <ion-icon name="person-add-outline"></ion-icon>
                        </span>
                        <span class="title"> Artist Profile Form</span>
                    </a>
                </li>

                  <li>
                    <a href="artistprofile_details.php">
                        <span class="icon">
                            <ion-icon name="person-add-outline"></ion-icon>
                        </span>
                        <span class="title"> Artist Details </span>
                    </a>
                </li>

                

                <li>
                     <a href="booking_info.php">
                        <span class="icon">
                             <ion-icon name="receipt-outline"></ion-icon> 
                        </span>
                        <span class="title">Booking Information</span>
                    </a>
                </li>

                <li>
                    <a href="payment.php">
                        <span class="icon">
                            <ion-icon name="cash-outline"></ion-icon>
                        </span>
                        <span class="title"> Payment Notification </span>
                    </a>
                </li>
                <li>
                    <a href="admin_chat_dashboard.php">
                        <span class="icon">
                            <ion-icon name="logo-wechat"></ion-icon>
                        </span>
                        <span class="title"> Chat with Users</span>
                    </a>
                </li>


                <li>
                    <a href="signout.php">
                        <span class="icon">
                            <ion-icon name="exit-outline"></ion-icon>
                        </span>
                        <span class="title"> Sign Out</span>
                    </a>
                </li>
            </ul>
</aside>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </ul>


</aside>