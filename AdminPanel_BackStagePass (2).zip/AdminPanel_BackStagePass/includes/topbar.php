<div class="topbar">
                  <div class="toggle"onclick="toggleNav()">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text"  placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="./assets/BACKSTAGE_PICTURES/userprofile.png" alt="User Profile">
                
                </div>

                </div>
            </div>
